﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class OperatingWithDivisions : Form
    {
        public OperatingWithDivisions()
        {
            InitializeComponent();
        }

        private void Read_Click(object sender, EventArgs e)
        {
            ReadDivisions readDivisions = new ReadDivisions();
            readDivisions.Show();
            this.Hide();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            AddDivision addDivision = new AddDivision();
            addDivision.Show();
            this.Hide();
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            DeleteDivision deleteDivision = new DeleteDivision();
            deleteDivision.Show();
            this.Hide();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
            this.Hide();
        }
    }
}
