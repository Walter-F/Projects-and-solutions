﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class AddDivision : Form
    {
        public AddDivision()
        {
            InitializeComponent();
        }

        private void ConfirmAdd_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("INSERT INTO `divisions` (`ID`, `Наименование`, `Головное подразделение`) " +
                "VALUES (NULL, @Name, @HeadDivision)", db.getConnection());
            command.Parameters.Add("@Name", MySqlDbType.VarChar).Value = NameDivision.Text;
            command.Parameters.Add("@HeadDivision", MySqlDbType.VarChar).Value = HeadDivision.Text;


            if (command.ExecuteNonQuery() != 1)
            {
                MessageBox.Show(
               "Произошла ошибка при добавлении подразделения!",
               "Ошибка!",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(
                "Подразделение было успешно добавлено!",
                "Успех!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }

            db.closeConnection();
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
            this.Hide();
        }
    }
}
