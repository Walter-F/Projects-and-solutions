﻿namespace EmployeeAccounting
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.FIOTB = new System.Windows.Forms.TextBox();
            this.TabNumberTB = new System.Windows.Forms.TextBox();
            this.PostTB = new System.Windows.Forms.TextBox();
            this.TelephoneTB = new System.Windows.Forms.TextBox();
            this.EmailTB = new System.Windows.Forms.TextBox();
            this.DivisionTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.AdmissionDate = new System.Windows.Forms.DateTimePicker();
            this.DismissionDate = new System.Windows.Forms.DateTimePicker();
            this.DismissionCB = new System.Windows.Forms.CheckBox();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            this.ConfirmAdd = new EmployeeAccounting.Components.RJButton();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(0, -1);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 66);
            this.WelcomeLabel.TabIndex = 19;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FIOTB
            // 
            this.FIOTB.Location = new System.Drawing.Point(316, 206);
            this.FIOTB.Multiline = true;
            this.FIOTB.Name = "FIOTB";
            this.FIOTB.Size = new System.Drawing.Size(362, 34);
            this.FIOTB.TabIndex = 21;
            // 
            // TabNumberTB
            // 
            this.TabNumberTB.Location = new System.Drawing.Point(316, 246);
            this.TabNumberTB.Multiline = true;
            this.TabNumberTB.Name = "TabNumberTB";
            this.TabNumberTB.Size = new System.Drawing.Size(362, 34);
            this.TabNumberTB.TabIndex = 22;
            // 
            // PostTB
            // 
            this.PostTB.Location = new System.Drawing.Point(316, 286);
            this.PostTB.Multiline = true;
            this.PostTB.Name = "PostTB";
            this.PostTB.Size = new System.Drawing.Size(362, 34);
            this.PostTB.TabIndex = 23;
            // 
            // TelephoneTB
            // 
            this.TelephoneTB.Location = new System.Drawing.Point(316, 406);
            this.TelephoneTB.Multiline = true;
            this.TelephoneTB.Name = "TelephoneTB";
            this.TelephoneTB.Size = new System.Drawing.Size(362, 34);
            this.TelephoneTB.TabIndex = 26;
            // 
            // EmailTB
            // 
            this.EmailTB.Location = new System.Drawing.Point(316, 366);
            this.EmailTB.Multiline = true;
            this.EmailTB.Name = "EmailTB";
            this.EmailTB.Size = new System.Drawing.Size(362, 34);
            this.EmailTB.TabIndex = 25;
            // 
            // DivisionTB
            // 
            this.DivisionTB.Location = new System.Drawing.Point(316, 326);
            this.DivisionTB.Multiline = true;
            this.DivisionTB.Name = "DivisionTB";
            this.DivisionTB.Size = new System.Drawing.Size(362, 34);
            this.DivisionTB.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(155, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 21);
            this.label1.TabIndex = 29;
            this.label1.Text = "ФИО";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label2.Location = new System.Drawing.Point(155, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 21);
            this.label2.TabIndex = 30;
            this.label2.Text = "Табельный номер";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label3.Location = new System.Drawing.Point(155, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 21);
            this.label3.TabIndex = 31;
            this.label3.Text = "Должность";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label4.Location = new System.Drawing.Point(155, 403);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 21);
            this.label4.TabIndex = 34;
            this.label4.Text = "Телефон";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label5.Location = new System.Drawing.Point(155, 360);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 21);
            this.label5.TabIndex = 33;
            this.label5.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label6.Location = new System.Drawing.Point(155, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 21);
            this.label6.TabIndex = 32;
            this.label6.Text = "Подразделение";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label7.Location = new System.Drawing.Point(155, 483);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 21);
            this.label7.TabIndex = 36;
            this.label7.Text = "Дата увольнения";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label8.Location = new System.Drawing.Point(155, 446);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 21);
            this.label8.TabIndex = 35;
            this.label8.Text = "Дата прима";
            // 
            // AdmissionDate
            // 
            this.AdmissionDate.Location = new System.Drawing.Point(316, 447);
            this.AdmissionDate.Name = "AdmissionDate";
            this.AdmissionDate.Size = new System.Drawing.Size(362, 20);
            this.AdmissionDate.TabIndex = 37;
            // 
            // DismissionDate
            // 
            this.DismissionDate.Location = new System.Drawing.Point(316, 486);
            this.DismissionDate.Name = "DismissionDate";
            this.DismissionDate.Size = new System.Drawing.Size(362, 20);
            this.DismissionDate.TabIndex = 38;
            // 
            // DismissionCB
            // 
            this.DismissionCB.AutoSize = true;
            this.DismissionCB.Location = new System.Drawing.Point(699, 488);
            this.DismissionCB.Name = "DismissionCB";
            this.DismissionCB.Size = new System.Drawing.Size(177, 17);
            this.DismissionCB.TabIndex = 39;
            this.DismissionCB.Text = "Дата увольнения отсутствует";
            this.DismissionCB.UseVisualStyleBackColor = true;
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(30, 68);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 40;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // ConfirmAdd
            // 
            this.ConfirmAdd.BackColor = System.Drawing.Color.White;
            this.ConfirmAdd.BackgroundColor = System.Drawing.Color.White;
            this.ConfirmAdd.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.ConfirmAdd.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ConfirmAdd.BorderRadius = 20;
            this.ConfirmAdd.BorderSize = 1;
            this.ConfirmAdd.FlatAppearance.BorderSize = 0;
            this.ConfirmAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmAdd.ForeColor = System.Drawing.Color.Black;
            this.ConfirmAdd.Location = new System.Drawing.Point(407, 550);
            this.ConfirmAdd.Name = "ConfirmAdd";
            this.ConfirmAdd.Size = new System.Drawing.Size(150, 40);
            this.ConfirmAdd.TabIndex = 20;
            this.ConfirmAdd.Text = "Подтвердить";
            this.ConfirmAdd.TextColor = System.Drawing.Color.Black;
            this.ConfirmAdd.UseVisualStyleBackColor = false;
            this.ConfirmAdd.Click += new System.EventHandler(this.ConfirmAdd_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(835, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 18;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(776, 12);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 17;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 770);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.DismissionCB);
            this.Controls.Add(this.DismissionDate);
            this.Controls.Add(this.AdmissionDate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TelephoneTB);
            this.Controls.Add(this.EmailTB);
            this.Controls.Add(this.DivisionTB);
            this.Controls.Add(this.PostTB);
            this.Controls.Add(this.TabNumberTB);
            this.Controls.Add(this.FIOTB);
            this.Controls.Add(this.ConfirmAdd);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddEmployee";
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private Components.RJButton ConfirmAdd;
        private System.Windows.Forms.TextBox FIOTB;
        private System.Windows.Forms.TextBox TabNumberTB;
        private System.Windows.Forms.TextBox PostTB;
        private System.Windows.Forms.TextBox TelephoneTB;
        private System.Windows.Forms.TextBox EmailTB;
        private System.Windows.Forms.TextBox DivisionTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker AdmissionDate;
        private System.Windows.Forms.DateTimePicker DismissionDate;
        private System.Windows.Forms.CheckBox DismissionCB;
        private System.Windows.Forms.PictureBox ReturnButton;
    }
}