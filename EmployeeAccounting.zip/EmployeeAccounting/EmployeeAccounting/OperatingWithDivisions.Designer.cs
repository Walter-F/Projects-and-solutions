﻿namespace EmployeeAccounting
{
    partial class OperatingWithDivisions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            this.Read = new EmployeeAccounting.Components.RJButton();
            this.Add = new EmployeeAccounting.Components.RJButton();
            this.Remove = new EmployeeAccounting.Components.RJButton();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(0, 9);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 66);
            this.WelcomeLabel.TabIndex = 47;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(28, 78);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 48;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(735, 22);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 46;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(676, 22);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 45;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // Read
            // 
            this.Read.BackColor = System.Drawing.Color.White;
            this.Read.BackgroundColor = System.Drawing.Color.White;
            this.Read.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.Read.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Read.BorderRadius = 20;
            this.Read.BorderSize = 1;
            this.Read.FlatAppearance.BorderSize = 0;
            this.Read.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Read.ForeColor = System.Drawing.Color.Black;
            this.Read.Location = new System.Drawing.Point(315, 183);
            this.Read.Name = "Read";
            this.Read.Size = new System.Drawing.Size(150, 40);
            this.Read.TabIndex = 57;
            this.Read.Text = "Просмотр подразделений";
            this.Read.TextColor = System.Drawing.Color.Black;
            this.Read.UseVisualStyleBackColor = false;
            this.Read.Click += new System.EventHandler(this.Read_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.White;
            this.Add.BackgroundColor = System.Drawing.Color.White;
            this.Add.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.Add.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Add.BorderRadius = 20;
            this.Add.BorderSize = 1;
            this.Add.FlatAppearance.BorderSize = 0;
            this.Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add.ForeColor = System.Drawing.Color.Black;
            this.Add.Location = new System.Drawing.Point(315, 229);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(150, 40);
            this.Add.TabIndex = 58;
            this.Add.Text = "Добавление подразделения";
            this.Add.TextColor = System.Drawing.Color.Black;
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Remove
            // 
            this.Remove.BackColor = System.Drawing.Color.White;
            this.Remove.BackgroundColor = System.Drawing.Color.White;
            this.Remove.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.Remove.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Remove.BorderRadius = 20;
            this.Remove.BorderSize = 1;
            this.Remove.FlatAppearance.BorderSize = 0;
            this.Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Remove.ForeColor = System.Drawing.Color.Black;
            this.Remove.Location = new System.Drawing.Point(315, 275);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(150, 40);
            this.Remove.TabIndex = 59;
            this.Remove.Text = "Удаление подразделения";
            this.Remove.TextColor = System.Drawing.Color.Black;
            this.Remove.UseVisualStyleBackColor = false;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // OperatingWithDivisions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Read);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OperatingWithDivisions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OperatingWithDivisions";
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox ReturnButton;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private Components.RJButton Read;
        private Components.RJButton Add;
        private Components.RJButton Remove;
    }
}