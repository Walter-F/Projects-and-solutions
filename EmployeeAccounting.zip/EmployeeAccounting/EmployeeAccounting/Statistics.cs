﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class Statistics : Form
    {
        public Statistics()
        {
            InitializeComponent();
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void FinByPeriod_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            if(AdmissionRB.Checked)
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM `history` WHERE `Дата приема` >= @FirstDate AND `Дата приема` <= @SecondDate", db.getConnection());
                command.Parameters.Add("@FirstDate", MySqlDbType.Date).Value = FirstDate.Value;
                command.Parameters.Add("@SecondDate", MySqlDbType.Date).Value = SecondDate.Value;
                adapter.SelectCommand = command;
                adapter.Fill(table);

                TableDataBase.DataSource = table;
            } else
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM `history` WHERE `Дата увольнения` >= @FirstDate AND `Дата увольнения` <= @SecondDate", db.getConnection());
                command.Parameters.Add("@FirstDate", MySqlDbType.Date).Value = FirstDate.Value;
                command.Parameters.Add("@SecondDate", MySqlDbType.Date).Value = SecondDate.Value;
                adapter.SelectCommand = command;
                adapter.Fill(table);

                TableDataBase.DataSource = table;
            }

            db.closeConnection();
        }

        private void FindByDivisionButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `history` WHERE `Подразделение` = @division", db.getConnection());
            command.Parameters.Add("@division", MySqlDbType.VarChar).Value = StatisticsByDivision.Text;
            adapter.SelectCommand = command;
            adapter.Fill(table);

            TableDataBase.DataSource = table;

            db.closeConnection();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
            this.Hide();
        }
    }
}
