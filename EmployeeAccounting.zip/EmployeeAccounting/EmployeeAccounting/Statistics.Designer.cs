﻿namespace EmployeeAccounting
{
    partial class Statistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.StatisticsByDivision = new System.Windows.Forms.TextBox();
            this.FinByPeriod = new EmployeeAccounting.Components.RJButton();
            this.FindByDivisionButton = new EmployeeAccounting.Components.RJButton();
            this.FirstDate = new System.Windows.Forms.DateTimePicker();
            this.SecondDate = new System.Windows.Forms.DateTimePicker();
            this.TableDataBase = new System.Windows.Forms.DataGridView();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            this.DismissionRB = new System.Windows.Forms.RadioButton();
            this.AdmissionRB = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TableDataBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(1, 9);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(440, 70);
            this.WelcomeLabel.TabIndex = 22;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(1428, 9);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 21;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(1369, 9);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 20;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label3.Location = new System.Drawing.Point(592, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(300, 32);
            this.label3.TabIndex = 32;
            this.label3.Text = "Статистика по подразделению";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(236, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 32);
            this.label1.TabIndex = 30;
            this.label1.Text = "Период";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // StatisticsByDivision
            // 
            this.StatisticsByDivision.Location = new System.Drawing.Point(660, 149);
            this.StatisticsByDivision.Multiline = true;
            this.StatisticsByDivision.Name = "StatisticsByDivision";
            this.StatisticsByDivision.Size = new System.Drawing.Size(148, 35);
            this.StatisticsByDivision.TabIndex = 29;
            // 
            // FinByPeriod
            // 
            this.FinByPeriod.BackColor = System.Drawing.Color.White;
            this.FinByPeriod.BackgroundColor = System.Drawing.Color.White;
            this.FinByPeriod.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.FinByPeriod.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FinByPeriod.BorderRadius = 20;
            this.FinByPeriod.BorderSize = 1;
            this.FinByPeriod.FlatAppearance.BorderSize = 0;
            this.FinByPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FinByPeriod.ForeColor = System.Drawing.Color.Black;
            this.FinByPeriod.Location = new System.Drawing.Point(252, 231);
            this.FinByPeriod.Name = "FinByPeriod";
            this.FinByPeriod.Size = new System.Drawing.Size(150, 40);
            this.FinByPeriod.TabIndex = 25;
            this.FinByPeriod.Text = "Подтвердить";
            this.FinByPeriod.TextColor = System.Drawing.Color.Black;
            this.FinByPeriod.UseVisualStyleBackColor = false;
            this.FinByPeriod.Click += new System.EventHandler(this.FinByPeriod_Click);
            // 
            // FindByDivisionButton
            // 
            this.FindByDivisionButton.BackColor = System.Drawing.Color.White;
            this.FindByDivisionButton.BackgroundColor = System.Drawing.Color.White;
            this.FindByDivisionButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.FindByDivisionButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FindByDivisionButton.BorderRadius = 20;
            this.FindByDivisionButton.BorderSize = 1;
            this.FindByDivisionButton.FlatAppearance.BorderSize = 0;
            this.FindByDivisionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FindByDivisionButton.ForeColor = System.Drawing.Color.Black;
            this.FindByDivisionButton.Location = new System.Drawing.Point(658, 208);
            this.FindByDivisionButton.Name = "FindByDivisionButton";
            this.FindByDivisionButton.Size = new System.Drawing.Size(150, 40);
            this.FindByDivisionButton.TabIndex = 24;
            this.FindByDivisionButton.Text = "Подтвердить";
            this.FindByDivisionButton.TextColor = System.Drawing.Color.Black;
            this.FindByDivisionButton.UseVisualStyleBackColor = false;
            this.FindByDivisionButton.Click += new System.EventHandler(this.FindByDivisionButton_Click);
            // 
            // FirstDate
            // 
            this.FirstDate.Location = new System.Drawing.Point(108, 149);
            this.FirstDate.Name = "FirstDate";
            this.FirstDate.Size = new System.Drawing.Size(200, 20);
            this.FirstDate.TabIndex = 33;
            // 
            // SecondDate
            // 
            this.SecondDate.Location = new System.Drawing.Point(323, 149);
            this.SecondDate.Name = "SecondDate";
            this.SecondDate.Size = new System.Drawing.Size(200, 20);
            this.SecondDate.TabIndex = 34;
            // 
            // TableDataBase
            // 
            this.TableDataBase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TableDataBase.Location = new System.Drawing.Point(93, 298);
            this.TableDataBase.Name = "TableDataBase";
            this.TableDataBase.Size = new System.Drawing.Size(944, 390);
            this.TableDataBase.TabIndex = 35;
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(30, 84);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 42;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // DismissionRB
            // 
            this.DismissionRB.AutoSize = true;
            this.DismissionRB.Location = new System.Drawing.Point(271, 208);
            this.DismissionRB.Name = "DismissionRB";
            this.DismissionRB.Size = new System.Drawing.Size(87, 17);
            this.DismissionRB.TabIndex = 43;
            this.DismissionRB.TabStop = true;
            this.DismissionRB.Text = "Увольнение";
            this.DismissionRB.UseVisualStyleBackColor = true;
            // 
            // AdmissionRB
            // 
            this.AdmissionRB.AutoSize = true;
            this.AdmissionRB.Location = new System.Drawing.Point(271, 185);
            this.AdmissionRB.Name = "AdmissionRB";
            this.AdmissionRB.Size = new System.Drawing.Size(121, 17);
            this.AdmissionRB.TabIndex = 44;
            this.AdmissionRB.TabStop = true;
            this.AdmissionRB.Text = "Зачисление в штат";
            this.AdmissionRB.UseVisualStyleBackColor = true;
            // 
            // Statistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1500, 860);
            this.Controls.Add(this.AdmissionRB);
            this.Controls.Add(this.DismissionRB);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.TableDataBase);
            this.Controls.Add(this.SecondDate);
            this.Controls.Add(this.FirstDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StatisticsByDivision);
            this.Controls.Add(this.FinByPeriod);
            this.Controls.Add(this.FindByDivisionButton);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Statistics";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Statistics";
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TableDataBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox StatisticsByDivision;
        private Components.RJButton FinByPeriod;
        private Components.RJButton FindByDivisionButton;
        private System.Windows.Forms.DateTimePicker FirstDate;
        private System.Windows.Forms.DateTimePicker SecondDate;
        private System.Windows.Forms.DataGridView TableDataBase;
        private System.Windows.Forms.PictureBox ReturnButton;
        private System.Windows.Forms.RadioButton DismissionRB;
        private System.Windows.Forms.RadioButton AdmissionRB;
    }
}