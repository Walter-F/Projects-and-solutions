﻿namespace EmployeeAccounting
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FindByName = new System.Windows.Forms.TextBox();
            this.FindByNumber = new System.Windows.Forms.TextBox();
            this.FindByDivision = new System.Windows.Forms.TextBox();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.TableDataBase = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FinByNameButton = new EmployeeAccounting.Components.RJButton();
            this.FindByDivisionButton = new EmployeeAccounting.Components.RJButton();
            this.FindByNumberButton = new EmployeeAccounting.Components.RJButton();
            this.HistoryButton = new EmployeeAccounting.Components.RJButton();
            this.DismissionEmployeeButton = new EmployeeAccounting.Components.RJButton();
            this.AddingEmployeeButton = new EmployeeAccounting.Components.RJButton();
            this.EditingDivisions = new EmployeeAccounting.Components.RJButton();
            this.Refresh = new EmployeeAccounting.Components.RJButton();
            ((System.ComponentModel.ISupportInitialize)(this.TableDataBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // FindByName
            // 
            this.FindByName.Location = new System.Drawing.Point(68, 129);
            this.FindByName.Multiline = true;
            this.FindByName.Name = "FindByName";
            this.FindByName.Size = new System.Drawing.Size(148, 35);
            this.FindByName.TabIndex = 9;
            // 
            // FindByNumber
            // 
            this.FindByNumber.Location = new System.Drawing.Point(224, 129);
            this.FindByNumber.Multiline = true;
            this.FindByNumber.Name = "FindByNumber";
            this.FindByNumber.Size = new System.Drawing.Size(148, 35);
            this.FindByNumber.TabIndex = 12;
            // 
            // FindByDivision
            // 
            this.FindByDivision.Location = new System.Drawing.Point(380, 129);
            this.FindByDivision.Multiline = true;
            this.FindByDivision.Name = "FindByDivision";
            this.FindByDivision.Size = new System.Drawing.Size(148, 35);
            this.FindByDivision.TabIndex = 13;
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(-3, -1);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 86);
            this.WelcomeLabel.TabIndex = 16;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TableDataBase
            // 
            this.TableDataBase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TableDataBase.Location = new System.Drawing.Point(55, 243);
            this.TableDataBase.Name = "TableDataBase";
            this.TableDataBase.Size = new System.Drawing.Size(944, 390);
            this.TableDataBase.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(64, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 32);
            this.label1.TabIndex = 18;
            this.label1.Text = "Поиск по имени";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label2.Location = new System.Drawing.Point(222, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 32);
            this.label2.TabIndex = 19;
            this.label2.Text = "Поиск по номеру";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label3.Location = new System.Drawing.Point(380, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 32);
            this.label3.TabIndex = 20;
            this.label3.Text = "Поиск по подразделению";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(1419, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 15;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(1360, 12);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 14;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Search;
            this.pictureBox1.Location = new System.Drawing.Point(12, 129);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // FinByNameButton
            // 
            this.FinByNameButton.BackColor = System.Drawing.Color.White;
            this.FinByNameButton.BackgroundColor = System.Drawing.Color.White;
            this.FinByNameButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.FinByNameButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FinByNameButton.BorderRadius = 20;
            this.FinByNameButton.BorderSize = 1;
            this.FinByNameButton.FlatAppearance.BorderSize = 0;
            this.FinByNameButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FinByNameButton.ForeColor = System.Drawing.Color.Black;
            this.FinByNameButton.Location = new System.Drawing.Point(66, 170);
            this.FinByNameButton.Name = "FinByNameButton";
            this.FinByNameButton.Size = new System.Drawing.Size(150, 40);
            this.FinByNameButton.TabIndex = 7;
            this.FinByNameButton.Text = "Подтвердить";
            this.FinByNameButton.TextColor = System.Drawing.Color.Black;
            this.FinByNameButton.UseVisualStyleBackColor = false;
            this.FinByNameButton.Click += new System.EventHandler(this.FinByNameButton_Click);
            // 
            // FindByDivisionButton
            // 
            this.FindByDivisionButton.BackColor = System.Drawing.Color.White;
            this.FindByDivisionButton.BackgroundColor = System.Drawing.Color.White;
            this.FindByDivisionButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.FindByDivisionButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FindByDivisionButton.BorderRadius = 20;
            this.FindByDivisionButton.BorderSize = 1;
            this.FindByDivisionButton.FlatAppearance.BorderSize = 0;
            this.FindByDivisionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FindByDivisionButton.ForeColor = System.Drawing.Color.Black;
            this.FindByDivisionButton.Location = new System.Drawing.Point(378, 170);
            this.FindByDivisionButton.Name = "FindByDivisionButton";
            this.FindByDivisionButton.Size = new System.Drawing.Size(150, 40);
            this.FindByDivisionButton.TabIndex = 6;
            this.FindByDivisionButton.Text = "Подтвердить";
            this.FindByDivisionButton.TextColor = System.Drawing.Color.Black;
            this.FindByDivisionButton.UseVisualStyleBackColor = false;
            this.FindByDivisionButton.Click += new System.EventHandler(this.FindByDivisionButton_Click);
            // 
            // FindByNumberButton
            // 
            this.FindByNumberButton.BackColor = System.Drawing.Color.White;
            this.FindByNumberButton.BackgroundColor = System.Drawing.Color.White;
            this.FindByNumberButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.FindByNumberButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FindByNumberButton.BorderRadius = 20;
            this.FindByNumberButton.BorderSize = 1;
            this.FindByNumberButton.FlatAppearance.BorderSize = 0;
            this.FindByNumberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FindByNumberButton.ForeColor = System.Drawing.Color.Black;
            this.FindByNumberButton.Location = new System.Drawing.Point(222, 170);
            this.FindByNumberButton.Name = "FindByNumberButton";
            this.FindByNumberButton.Size = new System.Drawing.Size(150, 40);
            this.FindByNumberButton.TabIndex = 5;
            this.FindByNumberButton.Text = "Подтвердить";
            this.FindByNumberButton.TextColor = System.Drawing.Color.Black;
            this.FindByNumberButton.UseVisualStyleBackColor = false;
            this.FindByNumberButton.Click += new System.EventHandler(this.FindByNumberButton_Click);
            // 
            // HistoryButton
            // 
            this.HistoryButton.BackColor = System.Drawing.Color.White;
            this.HistoryButton.BackgroundColor = System.Drawing.Color.White;
            this.HistoryButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.HistoryButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.HistoryButton.BorderRadius = 20;
            this.HistoryButton.BorderSize = 1;
            this.HistoryButton.FlatAppearance.BorderSize = 0;
            this.HistoryButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HistoryButton.ForeColor = System.Drawing.Color.Black;
            this.HistoryButton.Location = new System.Drawing.Point(1056, 400);
            this.HistoryButton.Name = "HistoryButton";
            this.HistoryButton.Size = new System.Drawing.Size(150, 40);
            this.HistoryButton.TabIndex = 4;
            this.HistoryButton.Text = "Статистика";
            this.HistoryButton.TextColor = System.Drawing.Color.Black;
            this.HistoryButton.UseVisualStyleBackColor = false;
            this.HistoryButton.Click += new System.EventHandler(this.HistoryButton_Click);
            // 
            // DismissionEmployeeButton
            // 
            this.DismissionEmployeeButton.BackColor = System.Drawing.Color.White;
            this.DismissionEmployeeButton.BackgroundColor = System.Drawing.Color.White;
            this.DismissionEmployeeButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.DismissionEmployeeButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DismissionEmployeeButton.BorderRadius = 20;
            this.DismissionEmployeeButton.BorderSize = 1;
            this.DismissionEmployeeButton.FlatAppearance.BorderSize = 0;
            this.DismissionEmployeeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DismissionEmployeeButton.ForeColor = System.Drawing.Color.Black;
            this.DismissionEmployeeButton.Location = new System.Drawing.Point(1056, 354);
            this.DismissionEmployeeButton.Name = "DismissionEmployeeButton";
            this.DismissionEmployeeButton.Size = new System.Drawing.Size(150, 40);
            this.DismissionEmployeeButton.TabIndex = 3;
            this.DismissionEmployeeButton.Text = "Увольнение сотрудника";
            this.DismissionEmployeeButton.TextColor = System.Drawing.Color.Black;
            this.DismissionEmployeeButton.UseVisualStyleBackColor = false;
            this.DismissionEmployeeButton.Click += new System.EventHandler(this.DismissionEmployeeButton_Click);
            // 
            // AddingEmployeeButton
            // 
            this.AddingEmployeeButton.BackColor = System.Drawing.Color.White;
            this.AddingEmployeeButton.BackgroundColor = System.Drawing.Color.White;
            this.AddingEmployeeButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.AddingEmployeeButton.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddingEmployeeButton.BorderRadius = 20;
            this.AddingEmployeeButton.BorderSize = 1;
            this.AddingEmployeeButton.FlatAppearance.BorderSize = 0;
            this.AddingEmployeeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddingEmployeeButton.ForeColor = System.Drawing.Color.Black;
            this.AddingEmployeeButton.Location = new System.Drawing.Point(1056, 311);
            this.AddingEmployeeButton.Name = "AddingEmployeeButton";
            this.AddingEmployeeButton.Size = new System.Drawing.Size(150, 40);
            this.AddingEmployeeButton.TabIndex = 2;
            this.AddingEmployeeButton.Text = "Добавление нового сотрудника";
            this.AddingEmployeeButton.TextColor = System.Drawing.Color.Black;
            this.AddingEmployeeButton.UseVisualStyleBackColor = false;
            this.AddingEmployeeButton.Click += new System.EventHandler(this.AddingEmployeeButton_Click);
            // 
            // EditingDivisions
            // 
            this.EditingDivisions.BackColor = System.Drawing.Color.White;
            this.EditingDivisions.BackgroundColor = System.Drawing.Color.White;
            this.EditingDivisions.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.EditingDivisions.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.EditingDivisions.BorderRadius = 20;
            this.EditingDivisions.BorderSize = 1;
            this.EditingDivisions.FlatAppearance.BorderSize = 0;
            this.EditingDivisions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditingDivisions.ForeColor = System.Drawing.Color.Black;
            this.EditingDivisions.Location = new System.Drawing.Point(1056, 446);
            this.EditingDivisions.Name = "EditingDivisions";
            this.EditingDivisions.Size = new System.Drawing.Size(150, 40);
            this.EditingDivisions.TabIndex = 1;
            this.EditingDivisions.Text = "Изменение и просмотр справочников";
            this.EditingDivisions.TextColor = System.Drawing.Color.Black;
            this.EditingDivisions.UseVisualStyleBackColor = false;
            this.EditingDivisions.Click += new System.EventHandler(this.EditingDivisions_Click);
            // 
            // Refresh
            // 
            this.Refresh.BackColor = System.Drawing.Color.White;
            this.Refresh.BackgroundColor = System.Drawing.Color.White;
            this.Refresh.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.Refresh.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Refresh.BorderRadius = 20;
            this.Refresh.BorderSize = 1;
            this.Refresh.FlatAppearance.BorderSize = 0;
            this.Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Refresh.ForeColor = System.Drawing.Color.Black;
            this.Refresh.Location = new System.Drawing.Point(1056, 241);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(150, 40);
            this.Refresh.TabIndex = 0;
            this.Refresh.Text = "Обновить";
            this.Refresh.TextColor = System.Drawing.Color.Black;
            this.Refresh.UseVisualStyleBackColor = false;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1484, 821);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TableDataBase);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.Controls.Add(this.FindByDivision);
            this.Controls.Add(this.FindByNumber);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.FindByName);
            this.Controls.Add(this.FinByNameButton);
            this.Controls.Add(this.FindByDivisionButton);
            this.Controls.Add(this.FindByNumberButton);
            this.Controls.Add(this.HistoryButton);
            this.Controls.Add(this.DismissionEmployeeButton);
            this.Controls.Add(this.AddingEmployeeButton);
            this.Controls.Add(this.EditingDivisions);
            this.Controls.Add(this.Refresh);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainScreen";
            ((System.ComponentModel.ISupportInitialize)(this.TableDataBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Components.RJButton Refresh;
        private Components.RJButton EditingDivisions;
        private Components.RJButton AddingEmployeeButton;
        private Components.RJButton DismissionEmployeeButton;
        private Components.RJButton HistoryButton;
        private Components.RJButton FindByNumberButton;
        private Components.RJButton FindByDivisionButton;
        private Components.RJButton FinByNameButton;
        private System.Windows.Forms.TextBox FindByName;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox FindByNumber;
        private System.Windows.Forms.TextBox FindByDivision;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.DataGridView TableDataBase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}