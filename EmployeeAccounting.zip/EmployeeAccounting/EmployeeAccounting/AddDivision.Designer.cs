﻿namespace EmployeeAccounting
{
    partial class AddDivision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            this.NameDivision = new System.Windows.Forms.TextBox();
            this.HeadDivision = new System.Windows.Forms.TextBox();
            this.ConfirmAdd = new EmployeeAccounting.Components.RJButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(1, 9);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 66);
            this.WelcomeLabel.TabIndex = 43;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(29, 78);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 44;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(835, 22);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 42;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(776, 22);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 41;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // NameDivision
            // 
            this.NameDivision.Location = new System.Drawing.Point(345, 199);
            this.NameDivision.Multiline = true;
            this.NameDivision.Name = "NameDivision";
            this.NameDivision.Size = new System.Drawing.Size(192, 41);
            this.NameDivision.TabIndex = 45;
            // 
            // HeadDivision
            // 
            this.HeadDivision.Location = new System.Drawing.Point(345, 246);
            this.HeadDivision.Multiline = true;
            this.HeadDivision.Name = "HeadDivision";
            this.HeadDivision.Size = new System.Drawing.Size(192, 41);
            this.HeadDivision.TabIndex = 46;
            // 
            // ConfirmAdd
            // 
            this.ConfirmAdd.BackColor = System.Drawing.Color.White;
            this.ConfirmAdd.BackgroundColor = System.Drawing.Color.White;
            this.ConfirmAdd.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.ConfirmAdd.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ConfirmAdd.BorderRadius = 20;
            this.ConfirmAdd.BorderSize = 1;
            this.ConfirmAdd.FlatAppearance.BorderSize = 0;
            this.ConfirmAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmAdd.ForeColor = System.Drawing.Color.Black;
            this.ConfirmAdd.Location = new System.Drawing.Point(359, 308);
            this.ConfirmAdd.Name = "ConfirmAdd";
            this.ConfirmAdd.Size = new System.Drawing.Size(150, 40);
            this.ConfirmAdd.TabIndex = 47;
            this.ConfirmAdd.Text = "Подтвердить добавление";
            this.ConfirmAdd.TextColor = System.Drawing.Color.Black;
            this.ConfirmAdd.UseVisualStyleBackColor = false;
            this.ConfirmAdd.Click += new System.EventHandler(this.ConfirmAdd_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(145, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 36);
            this.label1.TabIndex = 48;
            this.label1.Text = "Наименование";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label2.Location = new System.Drawing.Point(145, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 36);
            this.label2.TabIndex = 49;
            this.label2.Text = "Головное подразделение";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AddDivision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 500);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ConfirmAdd);
            this.Controls.Add(this.HeadDivision);
            this.Controls.Add(this.NameDivision);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddDivision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddDivision";
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ReturnButton;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private System.Windows.Forms.TextBox NameDivision;
        private System.Windows.Forms.TextBox HeadDivision;
        private Components.RJButton ConfirmAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}