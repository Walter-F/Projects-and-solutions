﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class DeleteDivision : Form
    {
        public DeleteDivision()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
            this.Hide();
        }

        private void ConfirmDelete_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();

            MySqlCommand command2 = new MySqlCommand("DELETE FROM `divisions` WHERE `ID` = @ID", db.getConnection());
            command2.Parameters.Add("@ID", MySqlDbType.Int32).Value = IDDivisionForDeleting.Text;

            if (command2.ExecuteNonQuery() == 1)
                MessageBox.Show("Подразделение успешно удалено!");
            else
                MessageBox.Show("Произошла непредвиденая ошибка!");

            db.closeConnection();
        }
    }
}
