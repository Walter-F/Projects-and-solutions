﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void ConfirmAdd_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("INSERT INTO `employees` (`ID`, `ФИО`, `Табельный номер`, `Должность`, `Подразделение`, `Email`, `Телефон`, `Дата приема`, `Дата увольнения`) " +
                "VALUES (NULL, @FIO, @TabNumber, @Post, @Division, @Email, @TelephoneNumber, @Admission, @Dismission)", db.getConnection());
            command.Parameters.Add("@FIO", MySqlDbType.VarChar).Value = FIOTB.Text;
            command.Parameters.Add("@TabNumber", MySqlDbType.VarChar).Value = TabNumberTB.Text;
            command.Parameters.Add("@Post", MySqlDbType.VarChar).Value = PostTB.Text;
            command.Parameters.Add("@Division", MySqlDbType.VarChar).Value = DivisionTB.Text;
            command.Parameters.Add("@Email", MySqlDbType.VarChar).Value = EmailTB.Text;
            command.Parameters.Add("@TelephoneNumber", MySqlDbType.VarChar).Value = TelephoneTB.Text;
            command.Parameters.Add("@Admission", MySqlDbType.Date).Value = AdmissionDate.Value;
            if (DismissionCB.Checked)
            {
                command.Parameters.Add("@Dismission", MySqlDbType.Date).Value = null;
            }
            else
            {

                command.Parameters.Add("@Dismission", MySqlDbType.Date).Value = DismissionDate.Value;
            }


            if (command.ExecuteNonQuery() != 1)
            { 
                MessageBox.Show(
               "Произошла ошибка при добавлении сотрудника!",
               "Ошибка!",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error);
            } else
            {
                MessageBox.Show(
                "Сотрудник был успешно добавлен!",
                "Успех!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }

            MySqlCommand command2 = new MySqlCommand("INSERT INTO `history` (`ID`, `Категория`,`ФИО`, `Табельный номер`, `Должность`, `Подразделение`, `Email`, `Телефон`, `Дата приема`, `Дата увольнения`) " +
                "VALUES (NULL, @Category, @FIO, @TabNumber, @Post, @Division, @Email, @TelephoneNumber, @Admission, @Dismission2)", db.getConnection());
            command2.Parameters.Add("@Category", MySqlDbType.VarChar).Value = "Зачисление в штат";
            command2.Parameters.Add("@FIO", MySqlDbType.VarChar).Value = FIOTB.Text;
            command2.Parameters.Add("@TabNumber", MySqlDbType.VarChar).Value = TabNumberTB.Text;
            command2.Parameters.Add("@Post", MySqlDbType.VarChar).Value = PostTB.Text;
            command2.Parameters.Add("@Division", MySqlDbType.VarChar).Value = DivisionTB.Text;
            command2.Parameters.Add("@Email", MySqlDbType.VarChar).Value = EmailTB.Text;
            command2.Parameters.Add("@TelephoneNumber", MySqlDbType.VarChar).Value = TelephoneTB.Text;
            command2.Parameters.Add("@Admission", MySqlDbType.Date).Value = AdmissionDate.Value;
            if (DismissionCB.Checked)
            {
                command2.Parameters.Add("@Dismission2", MySqlDbType.Date).Value = null;
            }
            else
            {

                command2.Parameters.Add("@Dismission2", MySqlDbType.Date).Value = DismissionDate.Value;
            }

            if (command2.ExecuteNonQuery() != 1)
            {
                MessageBox.Show(
               "Произошла ошибка при добавлении сотрудника!",
               "Ошибка!",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(
                "Сотрудник был успешно добавлен!",
                "Успех!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }

            db.closeConnection();
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MainScreen mainScreen = new MainScreen();
            mainScreen.Show();
            this.Hide();
        }
    }
}
