﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeAccounting
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();

            LoadData();
        }

        private void LoadData()
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `employees` ORDER BY ID", db.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);

            TableDataBase.DataSource = table;

            db.closeConnection();
        }

        private void FinByNameButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `employees` WHERE `ФИО` = @FIO", db.getConnection());
            command.Parameters.Add("@FIO", MySqlDbType.VarChar).Value = FindByName.Text;
            adapter.SelectCommand = command;
            adapter.Fill(table);

            TableDataBase.DataSource = table;

            db.closeConnection();
        }

        private void FindByNumberButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `employees` WHERE `Табельный номер` = @number", db.getConnection());
            command.Parameters.Add("@number", MySqlDbType.VarChar).Value = FindByNumber.Text;
            adapter.SelectCommand = command;    
            adapter.Fill(table);

            TableDataBase.DataSource = table;

            db.closeConnection();
        }

        private void FindByDivisionButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `employees` WHERE `Подразделение` = @division", db.getConnection());
            command.Parameters.Add("@division", MySqlDbType.VarChar).Value = FindByDivision.Text;
            adapter.SelectCommand = command;
            adapter.Fill(table);

            TableDataBase.DataSource = table;

            db.closeConnection();
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void Minimazed_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы уверены, что хотите завершить работу с программой?", "Внимание!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void AddingEmployeeButton_Click(object sender, EventArgs e)
        {
            AddEmployee addEmployee = new AddEmployee();
            addEmployee.Show();
            this.Hide();
        }

        private void DismissionEmployeeButton_Click(object sender, EventArgs e)
        {
            Dismission dismission = new Dismission();
            dismission.Show();
            this.Hide();
        }

        private void HistoryButton_Click(object sender, EventArgs e)
        {
            Statistics statistics = new Statistics();
            statistics.Show();
            this.Hide();
        }

        private void EditingDivisions_Click(object sender, EventArgs e)
        {
            OperatingWithDivisions operatingWithDivisions = new OperatingWithDivisions();
            operatingWithDivisions.Show();
            this.Hide();
        }
    }
}
