﻿namespace EmployeeAccounting
{
    partial class DeleteDivision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ConfirmDelete = new EmployeeAccounting.Components.RJButton();
            this.IDDivisionForDeleting = new System.Windows.Forms.TextBox();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(266, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 36);
            this.label1.TabIndex = 57;
            this.label1.Text = "Введите ID подразделения для удаления";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ConfirmDelete
            // 
            this.ConfirmDelete.BackColor = System.Drawing.Color.White;
            this.ConfirmDelete.BackgroundColor = System.Drawing.Color.White;
            this.ConfirmDelete.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.ConfirmDelete.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ConfirmDelete.BorderRadius = 20;
            this.ConfirmDelete.BorderSize = 1;
            this.ConfirmDelete.FlatAppearance.BorderSize = 0;
            this.ConfirmDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmDelete.ForeColor = System.Drawing.Color.Black;
            this.ConfirmDelete.Location = new System.Drawing.Point(345, 294);
            this.ConfirmDelete.Name = "ConfirmDelete";
            this.ConfirmDelete.Size = new System.Drawing.Size(150, 40);
            this.ConfirmDelete.TabIndex = 56;
            this.ConfirmDelete.Text = "Подтвердить удаление";
            this.ConfirmDelete.TextColor = System.Drawing.Color.Black;
            this.ConfirmDelete.UseVisualStyleBackColor = false;
            this.ConfirmDelete.Click += new System.EventHandler(this.ConfirmDelete_Click);
            // 
            // IDDivisionForDeleting
            // 
            this.IDDivisionForDeleting.Location = new System.Drawing.Point(329, 247);
            this.IDDivisionForDeleting.Multiline = true;
            this.IDDivisionForDeleting.Name = "IDDivisionForDeleting";
            this.IDDivisionForDeleting.Size = new System.Drawing.Size(192, 41);
            this.IDDivisionForDeleting.TabIndex = 54;
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(30, 73);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 53;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(2, 4);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 66);
            this.WelcomeLabel.TabIndex = 52;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(836, 17);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 51;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(777, 17);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 50;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // DeleteDivision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 500);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ConfirmDelete);
            this.Controls.Add(this.IDDivisionForDeleting);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DeleteDivision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DeleteDivision";
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Components.RJButton ConfirmDelete;
        private System.Windows.Forms.TextBox IDDivisionForDeleting;
        private System.Windows.Forms.PictureBox ReturnButton;
        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
    }
}