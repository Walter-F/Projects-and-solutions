﻿namespace EmployeeAccounting
{
    partial class Dismission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.PictureBox();
            this.Minimazed = new System.Windows.Forms.PictureBox();
            this.IDForDismisson = new System.Windows.Forms.TextBox();
            this.ConfirmDismission = new EmployeeAccounting.Components.RJButton();
            this.label1 = new System.Windows.Forms.Label();
            this.ReturnButton = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WelcomeLabel.BackColor = System.Drawing.Color.Transparent;
            this.WelcomeLabel.Font = new System.Drawing.Font("Yu Gothic UI Light", 16F);
            this.WelcomeLabel.Location = new System.Drawing.Point(-1, -1);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(445, 66);
            this.WelcomeLabel.TabIndex = 22;
            this.WelcomeLabel.Text = "Проекты и решения - учёт сотрудников";
            this.WelcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_Close_50px_1;
            this.Close.Location = new System.Drawing.Point(682, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(53, 53);
            this.Close.TabIndex = 21;
            this.Close.TabStop = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Minimazed
            // 
            this.Minimazed.BackColor = System.Drawing.Color.Transparent;
            this.Minimazed.BackgroundImage = global::EmployeeAccounting.Properties.Resources.icons8_expand_arrow_50px_1;
            this.Minimazed.Location = new System.Drawing.Point(623, 12);
            this.Minimazed.Name = "Minimazed";
            this.Minimazed.Size = new System.Drawing.Size(53, 53);
            this.Minimazed.TabIndex = 20;
            this.Minimazed.TabStop = false;
            this.Minimazed.Click += new System.EventHandler(this.Minimazed_Click);
            // 
            // IDForDismisson
            // 
            this.IDForDismisson.Location = new System.Drawing.Point(270, 250);
            this.IDForDismisson.Multiline = true;
            this.IDForDismisson.Name = "IDForDismisson";
            this.IDForDismisson.Size = new System.Drawing.Size(206, 31);
            this.IDForDismisson.TabIndex = 23;
            // 
            // ConfirmDismission
            // 
            this.ConfirmDismission.BackColor = System.Drawing.Color.White;
            this.ConfirmDismission.BackgroundColor = System.Drawing.Color.White;
            this.ConfirmDismission.BackgroundImage = global::EmployeeAccounting.Properties.Resources.ButtonBackground;
            this.ConfirmDismission.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ConfirmDismission.BorderRadius = 20;
            this.ConfirmDismission.BorderSize = 1;
            this.ConfirmDismission.FlatAppearance.BorderSize = 0;
            this.ConfirmDismission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmDismission.ForeColor = System.Drawing.Color.Black;
            this.ConfirmDismission.Location = new System.Drawing.Point(294, 297);
            this.ConfirmDismission.Name = "ConfirmDismission";
            this.ConfirmDismission.Size = new System.Drawing.Size(150, 40);
            this.ConfirmDismission.TabIndex = 24;
            this.ConfirmDismission.Text = "Подтвердить";
            this.ConfirmDismission.TextColor = System.Drawing.Color.Black;
            this.ConfirmDismission.UseVisualStyleBackColor = false;
            this.ConfirmDismission.Click += new System.EventHandler(this.ConfirmDismission_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI Light", 12F);
            this.label1.Location = new System.Drawing.Point(238, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 21);
            this.label1.TabIndex = 25;
            this.label1.Text = "Введите ID сотрудника для увольнения";
            // 
            // ReturnButton
            // 
            this.ReturnButton.BackgroundImage = global::EmployeeAccounting.Properties.Resources.Return;
            this.ReturnButton.Location = new System.Drawing.Point(31, 68);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(50, 50);
            this.ReturnButton.TabIndex = 41;
            this.ReturnButton.TabStop = false;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // Dismission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 500);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ConfirmDismission);
            this.Controls.Add(this.IDForDismisson);
            this.Controls.Add(this.WelcomeLabel);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimazed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dismission";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dismission";
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimazed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnButton)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeLabel;
        private System.Windows.Forms.PictureBox Close;
        private System.Windows.Forms.PictureBox Minimazed;
        private System.Windows.Forms.TextBox IDForDismisson;
        private Components.RJButton ConfirmDismission;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox ReturnButton;
    }
}